/* CheckBrand dashboard - vanilla JS, không phụ thuộc thư viện */
const $ = (s, el = document) => el.querySelector(s);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
const fmtDate = (d) => (d ? new Date(d).toLocaleDateString('vi-VN') : '-');
const fmtTime = (d) => (d ? new Date(d).toLocaleString('vi-VN', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit' }) : '-');
const pct = (v) => (v == null ? '-' : Math.round(v * 100) + '%');
const stars = (n) => '<span class="star">' + '★'.repeat(n || 0) + '</span>' + '<span class="muted">' + '☆'.repeat(5 - (n || 0)) + '</span>';
const cssv = (n) => `var(${n})`;

// Định dạng số kiểu Việt Nam: 4.66 -> "4,7" ; 1056 -> "1.056"
const fmtRating = (n, dec = 1) => (n == null ? '-' : Number(n).toLocaleString('vi-VN', { minimumFractionDigits: dec, maximumFractionDigits: dec }));
const fmtInt = (n) => (n == null ? '-' : Number(n).toLocaleString('vi-VN'));

// Ngày tương đối kiểu Google Maps
function timeAgo(date) {
  if (!date) return '-';
  const d = Math.floor((Date.now() - new Date(date)) / 864e5);
  if (d < 1) return 'hôm nay';
  if (d < 7) return `${d} ngày trước`;
  if (d < 30) return `${Math.floor(d / 7)} tuần trước`;
  if (d < 365) return `${Math.floor(d / 30)} tháng trước`;
  return `${Math.floor(d / 365)} năm trước`;
}

// Màu avatar cố định theo tên
function avatarColor(name) {
  const colors = ['#1a73e8', '#d93025', '#188038', '#e37400', '#9334e6', '#007b83', '#c5221f', '#185abc'];
  let h = 0;
  for (const ch of name) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  return colors[h % colors.length];
}

// Ẩn nút "Thêm" ở review ngắn (không bị cắt dòng)
function fitMore(root = document) {
  root.querySelectorAll('.rev .more-btn').forEach((b) => {
    const t = b.previousElementSibling;
    if (!t.classList.contains('open')) b.hidden = t.scrollHeight <= t.clientHeight + 1;
  });
}

const S = {
  brand: localStorage.getItem('cb-brand'),
  route: location.hash.slice(1) || 'overview',
  cfg: null,
  stars: '1',
  sort: 'newest',
  branch: '',
  rows: [],
  total: 0,
  days: 30,
};

const NAV = [
  ['Tổng quan', [['overview', '▦', 'Tổng quan'], ['sentiment', '◐', 'Sentiment Analysis'], ['topics', '✱', 'Topics & Keywords']]],
  ['Cạnh tranh', [['sov', '◎', 'Share of Voice'], ['social', '◈', 'Social Listening']]],
  ['Quản trị khủng hoảng', [['crisis', '⚠', 'Crisis Monitoring'], ['alerts', '🔔', 'Cảnh báo real-time']]],
  ['Tìm kiếm & danh tiếng', [['reviews', '★', 'Google Review'], ['reputation', '▤', 'Reputation Tracking']]],
  ['Báo cáo', [['reports', '▣', 'Báo cáo tự động']]],
];
const TITLES = Object.fromEntries(NAV.flatMap(([, items]) => items.map(([id, , t]) => [id, t])));
const LEVEL = { normal: ['Bình thường', 'good'], watch: ['Theo dõi', 'neu'], warning: ['Cảnh báo', 'warn'], critical: ['Khủng hoảng', 'bad'] };
const SENT = { positive: ['Tích cực', 'pos'], neutral: ['Trung tính', 'neu'], negative: ['Tiêu cực', 'neg'] };

const api = (p, opt) => fetch(`/api/${S.brand}/${p}`, opt).then((r) => r.json());
const post = (p, body = {}) => api(p, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) });

/* ---------- chart helpers ---------- */
function tipAttr(html) {
  return `data-tip="${esc(html)}"`;
}

function stacked(rows, { h = 190 } = {}) {
  const W = 640, P = { l: 30, r: 6, t: 8, b: 22 };
  const keys = [['negative', '--bad', 'Tiêu cực'], ['neutral', '--neutral', 'Trung tính'], ['positive', '--good', 'Tích cực']];
  const max = Math.max(1, ...rows.map((r) => r.total));
  const ph = h - P.t - P.b;
  const bw = (W - P.l - P.r) / rows.length;
  let g = '';
  for (let i = 0; i <= 4; i++) {
    const y = P.t + (ph * i) / 4;
    g += `<line x1="${P.l}" x2="${W - P.r}" y1="${y}" y2="${y}"/><text x="${P.l - 6}" y="${y + 4}" text-anchor="end">${Math.round(max - (max * i) / 4)}</text>`;
  }
  let bars = '';
  rows.forEach((r, i) => {
    const x = P.l + i * bw;
    let y = h - P.b;
    for (const [k, c] of keys) {
      const sh = (r[k] / max) * ph;
      if (sh > 0) {
        bars += `<rect x="${x + bw * 0.2}" y="${y - sh}" width="${bw * 0.6}" height="${sh}" fill="var(${c})" stroke="var(--surface-1)" stroke-width="2"/>`;
        y -= sh;
      }
    }
    const tip = `<b>Tuần ${fmtDate(r.week)}</b><br>Tích cực: ${r.positive}<br>Trung tính: ${r.neutral}<br>Tiêu cực: ${r.negative}` + (r.avg ? `<br>Sao TB: ${r.avg}` : '');
    bars += `<rect class="hit" x="${x}" y="${P.t}" width="${bw}" height="${ph}" fill="transparent" ${tipAttr(tip)}/>`;
    if (i % 2 === 0 || rows.length < 9) bars += `<text x="${x + bw / 2}" y="${h - 6}" text-anchor="middle">${new Date(r.week).toLocaleDateString('vi-VN', { day: '2-digit', month: '2-digit' })}</text>`;
  });
  return `<svg viewBox="0 0 ${W} ${h}" width="100%" role="img" aria-label="Review theo tuần"><g class="grid">${g}</g>${bars}</svg>
  <div class="legend">${keys.slice().reverse().map(([, c, l]) => `<span><i style="background:var(${c})"></i>${l}</span>`).join('')}</div>`;
}

function simpleBars(rows, { h = 150, color = '--bad', label = 'review tiêu cực' } = {}) {
  const W = 640, P = { l: 26, r: 6, t: 8, b: 22 };
  const max = Math.max(1, ...rows.map((r) => r.v));
  const ph = h - P.t - P.b;
  const bw = (W - P.l - P.r) / rows.length;
  let g = '';
  for (let i = 0; i <= 2; i++) {
    const y = P.t + (ph * i) / 2;
    g += `<line x1="${P.l}" x2="${W - P.r}" y1="${y}" y2="${y}"/><text x="${P.l - 6}" y="${y + 4}" text-anchor="end">${Math.round(max - (max * i) / 2)}</text>`;
  }
  let b = '';
  rows.forEach((r, i) => {
    const x = P.l + i * bw;
    const bh = (r.v / max) * ph;
    if (bh > 0) b += `<rect x="${x + bw * 0.18}" y="${h - P.b - bh}" width="${bw * 0.64}" height="${bh}" rx="2" fill="var(${color})"/>`;
    b += `<rect class="hit" x="${x}" y="${P.t}" width="${bw}" height="${ph}" fill="transparent" ${tipAttr(`<b>${fmtDate(r.k)}</b><br>${r.v} ${label}`)}/>`;
    if (i % 5 === 0) b += `<text x="${x + bw / 2}" y="${h - 6}" text-anchor="middle">${new Date(r.k).toLocaleDateString('vi-VN', { day: '2-digit', month: '2-digit' })}</text>`;
  });
  return `<svg viewBox="0 0 ${W} ${h}" width="100%"><g class="grid">${g}</g>${b}</svg>`;
}

function lineChart(labels, series, { h = 190, min = null, max = null, dec = 1 } = {}) {
  const W = 640, P = { l: 34, r: 10, t: 10, b: 22 };
  const vals = series.flatMap((s) => s.vals).filter((v) => v != null);
  if (!vals.length) return '<div class="empty">Chưa có dữ liệu</div>';
  const lo = min ?? Math.floor(Math.min(...vals) - 0.2), hi = max ?? Math.ceil(Math.max(...vals) + 0.2);
  const ph = h - P.t - P.b;
  const X = (i) => P.l + (labels.length === 1 ? (W - P.l - P.r) / 2 : (i * (W - P.l - P.r)) / (labels.length - 1));
  const Y = (v) => P.t + ph - ((v - lo) / (hi - lo || 1)) * ph;
  let g = '';
  for (let i = 0; i <= 4; i++) {
    const v = lo + ((hi - lo) * i) / 4;
    g += `<line x1="${P.l}" x2="${W - P.r}" y1="${Y(v)}" y2="${Y(v)}"/><text x="${P.l - 6}" y="${Y(v) + 4}" text-anchor="end">${+v.toFixed(dec)}</text>`;
  }
  let out = '';
  for (const s of series) {
    const pts = s.vals.map((v, i) => (v == null ? null : [X(i), Y(v)]));
    const d = pts.map((p, i) => (p ? `${pts[i - 1] ? 'L' : 'M'}${p[0]},${p[1]}` : '')).join('');
    out += `<path d="${d}" fill="none" stroke="var(${s.color})" stroke-width="2" stroke-linejoin="round"/>`;
    pts.forEach((p) => p && (out += `<circle cx="${p[0]}" cy="${p[1]}" r="3.5" fill="var(${s.color})" stroke="var(--surface-1)" stroke-width="2"/>`));
  }
  const cw = (W - P.l - P.r) / Math.max(1, labels.length - 1);
  labels.forEach((l, i) => {
    const tip = `<b>${esc(l)}</b>` + series.map((s) => `<br>${esc(s.name)}: ${s.vals[i] == null ? '-' : s.vals[i]}`).join('');
    out += `<rect class="hit" x="${X(i) - cw / 2}" y="${P.t}" width="${cw}" height="${ph}" fill="transparent" ${tipAttr(tip)}/>`;
    if (labels.length < 10 || i % Math.ceil(labels.length / 8) === 0) out += `<text x="${X(i)}" y="${h - 6}" text-anchor="middle">${esc(l)}</text>`;
  });
  const leg = series.length > 1 ? `<div class="legend">${series.map((s) => `<span><i style="background:var(${s.color})"></i>${esc(s.name)}</span>`).join('')}</div>` : '';
  return `<svg viewBox="0 0 ${W} ${h}" width="100%"><g class="grid">${g}</g>${out}</svg>${leg}`;
}

function donut(c) {
  const total = c.total || 1, R = 52, C = 2 * Math.PI * R;
  const parts = [['positive', '--good', 'Tích cực'], ['neutral', '--neutral', 'Trung tính'], ['negative', '--bad', 'Tiêu cực']];
  let off = 0, arcs = '';
  for (const [k, col, l] of parts) {
    const len = (c[k] / total) * C;
    if (len > 0) arcs += `<circle r="${R}" cx="70" cy="70" fill="none" stroke="var(${col})" stroke-width="18" stroke-dasharray="${Math.max(0, len - 2)} ${C}" stroke-dashoffset="${-off}" transform="rotate(-90 70 70)" ${tipAttr(`<b>${l}</b><br>${c[k]} (${pct(c[k] / total)})`)}/>`;
    off += len;
  }
  return `<div class="row" style="gap:22px;flex-wrap:wrap"><svg viewBox="0 0 140 140" width="150" height="150">${arcs}<text x="70" y="68" text-anchor="middle" style="font-size:22px;font-weight:650;fill:var(--text-primary)">${c.total}</text><text x="70" y="86" text-anchor="middle">review</text></svg>
  <div class="bars" style="min-width:190px">${parts.map(([k, col, l]) => `<div class="row"><i style="width:10px;height:10px;border-radius:2px;background:var(${col})"></i><span>${l}</span><b style="margin-left:auto">${c[k]}</b><span class="muted" style="width:44px;text-align:right">${pct(c[k] / total)}</span></div>`).join('')}</div></div>`;
}

const delta = (cur, prev, { inverse = false, dec = 0, unit = '' } = {}) => {
  if (cur == null || prev == null) return '<span class="muted">chưa đủ dữ liệu kỳ trước</span>';
  const d = +(cur - prev).toFixed(dec || 2);
  if (!d) return '<span class="muted">không đổi so với kỳ trước</span>';
  const good = inverse ? d < 0 : d > 0;
  return `<span class="${good ? 'up' : 'down'}">${d > 0 ? '▲' : '▼'} ${d % 1 ? fmtRating(Math.abs(d), 2) : fmtInt(Math.abs(d))}${unit}</span> <span class="muted">so với kỳ trước</span>`;
};

// Màu cố định theo thứ tự thương hiệu: brand mình xanh, đối thủ lần lượt các màu còn lại
const ENT_COLORS = ['--series-1', '--series-2', '--series-3', '--warn', '--seq-2', '--neutral'];
const entColor = (entities, id) => (id === 'other' ? '--neutral' : ENT_COLORS[Math.max(0, entities.findIndex((e) => e.id === id)) % ENT_COLORS.length]);

// Bảng so sánh đối thủ: dòng brand mình tô nền, ▲▼ so với snapshot ≥ 7 ngày trước
function compTable(rows, prev, { entities = null, extra = false, lastCompetitorSync = null } = {}) {
  const old = Object.fromEntries((prev?.entities || []).map((e) => [e.id, e]));
  const maxNeg = Math.max(0, ...rows.map((t) => t.negShare30 ?? 0));
  const chg = (cur, was, { dec = 2, int = false } = {}) => {
    if (cur == null || was == null) return '';
    const d = +(cur - was).toFixed(dec);
    if (!d) return '';
    return ` <span class="chg ${d > 0 ? 'up' : 'down'}">${d > 0 ? '▲' : '▼'}${int ? fmtInt(Math.abs(d)) : fmtRating(Math.abs(d), dec)}</span>`;
  };
  const dot = (id) => (entities ? `<i class="edot" style="background:var(${entColor(entities, id)})"></i>` : '');
  const negCls = (v) => [v != null && v > 0.1 ? 'negbad' : '', v && v === maxNeg ? 'negmax' : ''].join(' ');
  const body = rows.map((t) => {
    const o = old[t.id] || {};
    return `<tr class="${t.id === 'self' ? 'me' : ''}"><td>${dot(t.id)}${esc(t.name)}</td>
      <td class="num">${t.googleRating != null ? `${fmtRating(t.googleRating, 1)} <span class="star">★</span>${chg(t.googleRating, o.googleRating)}` : '-'}</td>
      <td class="num">${fmtInt(t.googleTotal)}${chg(t.googleTotal, o.googleTotal, { int: true, dec: 0 })}</td>
      <td class="num">${fmtRating(t.avg90, 2)}</td>
      <td class="num">${fmtInt(t.vol30)}</td>${extra ? `<td class="num">${fmtInt(t.volPrev30)}</td>` : ''}
      <td class="num"><span class="${negCls(t.negShare30)}">${pct(t.negShare30)}</span></td></tr>`;
  }).join('');
  const note = [
    prev ? `▲▼ so với ngày ${fmtDate(prev.date)}.` : 'Mũi tên ▲▼ so với tuần trước sẽ hiện khi hệ thống lưu đủ 7 ngày lịch sử.',
    'Điểm và tổng review Google lấy từ Google Maps; sao TB, số review và tỷ lệ tiêu cực tính trên review đã thu thập.',
    lastCompetitorSync ? `Đối thủ cập nhật mỗi ${S.cfg?.competitorDays ?? 7} ngày, lần gần nhất ${fmtDate(lastCompetitorSync)}.` : '',
  ].filter(Boolean).join(' ');
  return `<table class="comp"><tr><th>Thương hiệu</th><th class="num">Điểm Google</th><th class="num">Tổng review Google</th><th class="num">Sao TB 90 ngày</th><th class="num">Review 30 ngày</th>${extra ? '<th class="num">30 ngày trước đó</th>' : ''}<th class="num">Tỷ lệ tiêu cực</th></tr>${body}</table>
  <p class="muted" style="margin:8px 0 0;font-size:12px">${note}</p>`;
}

const reviewHtml = (r, { compact = false } = {}) => {
  const a = r.analysis || {};
  const [sl, sc] = SENT[a.sentiment] || ['', ''];
  const name = (r.author || '').trim() || 'Ẩn danh';
  const txt = (r.text || '').trim();
  // Chỉ gắn "Chưa phản hồi" khi đã thực sự kiểm tra trên Google (review lấy trước khi có tính năng này thì chưa rõ)
  const noReply = r.rating <= 3 && r.replyCheckedAt && !r.reply ? `<span class="chip noreply" title="Theo lần kiểm tra ngày ${fmtDate(r.replyCheckedAt)}">Chưa phản hồi</span>` : '';
  return `<div class="rev" data-id="${esc(r.id)}">
  <div class="rev-head"><span class="avatar" style="background:${avatarColor(name)}" aria-hidden="true">${esc([...name][0].toUpperCase())}</span><div>
    <div class="who">${esc(name)} ${r.src === 'mock' ? '<span class="chip mock">MẪU</span>' : ''}</div>
    <div class="meta">${stars(r.rating)} · <span title="Ngày đăng ${fmtDate(r.date)} · lấy dữ liệu ${fmtDate(r.fetchedAt)}">${timeAgo(r.date)}</span>${r.branch ? ` · ${esc(r.branch)}` : ''}</div>
  </div></div>
  <div class="rev-body">
    ${txt ? `<div class="txt">${esc(txt)}</div><button class="more-btn" data-act="expand">Thêm</button>` : '<div class="txt muted">Chỉ đánh giá sao</div>'}
    ${a.summary && r.lang !== 'vi' ? `<div class="meta">Tóm tắt (dịch): ${esc(a.summary)}</div>` : ''}
    ${compact ? (noReply ? `<div class="rev-chips">${noReply}</div>` : '') : `<div class="rev-chips">${noReply}${sl ? `<span class="chip ${sc}">${sl}</span>` : ''}${a.severity >= 2 ? `<span class="sev s${a.severity}">Mức ${a.severity}/3</span>` : ''}${(a.topics || []).map((t) => `<span class="chip">${esc(S.topicLabels?.[t] || t)}</span>`).join('')}</div>`}
    ${r.reply ? `<div class="owner-reply"><div class="meta"><b>Phản hồi của chủ sở hữu</b> · ${timeAgo(r.reply.date)}</div><div class="txt">${esc(r.reply.text)}</div><button class="more-btn" data-act="expand">Thêm</button></div>` : ''}
    <div class="rev-foot">${r.url ? `<a href="${esc(r.url)}" target="_blank" rel="noopener">Xem trên Google ↗</a>` : '<span class="muted">Dữ liệu mẫu</span>'}</div>
  </div></div>`;
};

const head = (title, sub, right = '') => `<div class="head"><div><h1>${title}</h1><p class="sub">${sub}</p></div><div>${right}</div></div>`;
const banner = () => (S.cfg?.mode === 'mock' ? '<div class="banner"><b>DỮ LIỆU MẪU.</b> Chưa có <code>SERPAPI_KEY</code> trong file <code>.env</code> nên toàn bộ số liệu bên dưới là giả lập. Điền key rồi khởi động lại để chuyển sang dữ liệu thật.</div>' : '');
const cur = () => S.cfg.brands.find((b) => b.id === S.brand);

/* ---------- pages ---------- */
const pages = {
  async overview() {
    const o = await api(`overview?days=${S.days}`);
    const k = o.kpi, h = o.health;
    const range = `<div class="tabs">${[7, 30, 90].map((d) => `<button class="btn ${S.days === d ? 'on' : ''}" data-act="range" data-v="${d}">${d} ngày</button>`).join('')}</div>`;
    const comps = h.components?.length
      ? h.components.map((c) => `<div class="bar"><span>${esc(c.label)}</span><div class="tr"><i style="width:${c.value}%;background:var(--series-1)"></i></div><b style="text-align:right">${c.value} <span class="muted">×${Math.round(c.weight * 100)}%</span></b></div>`).join('')
      : `<div class="muted">${esc(h.note || '')}</div>`;
    return (
      head('Tổng quan', `${esc(cur().name)} · ${esc(cur().industry)} · cập nhật ${fmtTime(o.lastSync)}`, range) + banner() +
      (o.level === 'critical' || o.level === 'warning' ? `<div class="banner crit">⚠ Trạng thái khủng hoảng: <b>${LEVEL[o.level][0]}</b>. Xem tab Crisis Monitoring.</div>` : '') +
      `<div class="grid g4" style="margin-bottom:14px">
        <div class="card kpi"><h3>Brand Health Score</h3><div class="v">${h.score ?? '-'}<span class="muted" style="font-size:15px">/100</span></div><div class="d">${h.delta != null ? delta(h.score, h.prev, { unit: ' điểm' }).replace('so với kỳ trước', 'so với 30 ngày trước') : esc(h.note || '')}</div></div>
        <div class="card kpi"><h3>Review ${o.days} ngày</h3><div class="v">${k.reviews}</div><div class="d">${delta(k.reviews, k.reviewsPrev)}</div></div>
        <div class="card kpi"><h3>Điểm sao trung bình</h3><div class="v">${fmtRating(k.avgRating, 2)} <span class="star">★</span></div><div class="d">${delta(k.avgRating, k.avgRatingPrev, { dec: 2 })}${k.googleAvg ? `<br>Google hiển thị: ${fmtRating(k.googleAvg, 1)}★ / ${fmtInt(k.googleTotal)} review` : ''}</div></div>
        <div class="card kpi"><h3>Review tiêu cực</h3><div class="v">${k.negative}</div><div class="d">${pct(k.negShare)} tổng review · ${delta(k.negative, k.negativePrev, { inverse: true })}</div></div></div>
      <div class="grid g21" style="margin-bottom:14px"><div class="card"><h3>Review theo tuần (12 tuần)</h3>${stacked(o.weekly)}</div>
      <div class="card"><h3>Phân bố số sao (${o.days} ngày)</h3><div class="bars">${[5, 4, 3, 2, 1].map((s) => { const m = Math.max(1, ...Object.values(o.dist)); return `<div class="bar" style="grid-template-columns:50px 1fr 40px"><span>${s} ★</span><div class="tr"><i style="width:${(o.dist[s] / m) * 100}%;background:var(--series-1)"></i></div><b style="text-align:right">${o.dist[s]}</b></div>`; }).join('')}</div></div></div>
      <div class="card"><h3>Cách tính Brand Health Score (trọng số hiển thị bên phải)</h3><div class="bars">${comps}</div></div>
      <div class="card"><h3>Theo chi nhánh (${o.days} ngày)</h3>${o.branches.length ? `<table><tr><th>Chi nhánh</th><th class="num">Review</th><th class="num">Sao TB</th><th class="num">Tiêu cực</th><th class="num">1★</th></tr>${o.branches.map((b) => `<tr><td>${esc(b.branch)}</td><td class="num">${b.total}</td><td class="num">${fmtRating(b.avg, 2)}</td><td class="num">${b.negative}</td><td class="num">${b.oneStar}</td></tr>`).join('')}</table>` : '<div class="empty">Chưa có review trong kỳ</div>'}</div>
      <div class="card"><h3>Review tiêu cực gần đây</h3>${o.latestNegative.map((r) => reviewHtml(r, { compact: true })).join('') || '<div class="empty">Không có</div>'}</div>`
    );
  },

  async sentiment() {
    const d = await api('sentiment?days=90');
    const langs = Object.entries(d.lang).sort((a, b) => b[1] - a[1]);
    return (
      head('Sentiment Analysis', 'Cảm xúc review Google, 90 ngày gần nhất') + banner() +
      `<div class="grid g2" style="margin-bottom:14px"><div class="card"><h3>Tỷ lệ cảm xúc</h3>${donut(d.counts)}<p class="muted" style="margin:10px 0 0">Phân tích bằng Claude: ${d.llm}/${d.total} review, còn lại dùng bộ luật theo số sao và từ khóa.</p></div>
      <div class="card"><h3>Ngôn ngữ review</h3><div class="bars">${langs.map(([l, n]) => `<div class="bar" style="grid-template-columns:70px 1fr 40px"><span>${{ vi: 'Tiếng Việt', en: 'Tiếng Anh', ru: 'Tiếng Nga', zh: 'Tiếng Trung', ko: 'Tiếng Hàn' }[l] || l}</span><div class="tr"><i style="width:${(n / d.total) * 100}%;background:var(--series-1)"></i></div><b style="text-align:right">${n}</b></div>`).join('')}</div></div></div>
      <div class="card"><h3>Xu hướng cảm xúc theo tuần</h3>${stacked(d.weekly)}</div>
      <div class="card"><h3>Theo chi nhánh</h3><table><tr><th>Chi nhánh</th><th class="num">Tích cực</th><th class="num">Trung tính</th><th class="num">Tiêu cực</th><th class="num">Tỷ lệ tiêu cực</th></tr>${d.branches.map((b) => `<tr><td>${esc(b.branch)}</td><td class="num">${b.sentiment.positive}</td><td class="num">${b.sentiment.neutral}</td><td class="num">${b.sentiment.negative}</td><td class="num">${pct(b.total ? b.sentiment.negative / b.total : null)}</td></tr>`).join('')}</table></div>`
    );
  },

  async topics() {
    const d = await api('topics?days=90');
    S.topicLabels = d.labels;
    const max = Math.max(1, ...d.topics.map((t) => t.total));
    return (
      head('Topics & Keywords', 'Chủ đề và từ khóa trong review, 90 ngày gần nhất') + banner() +
      `<div class="card"><h3>Chủ đề (sắp theo số review tiêu cực)</h3><div class="bars">${d.topics.map((t) => `<div class="bar"><span>${esc(t.label)}</span><div class="tr" style="width:${(t.total / max) * 100}%;min-width:4px">${['negative', 'neutral', 'positive'].map((k, i) => t[k] ? `<i ${tipAttr(`<b>${esc(t.label)}</b><br>${['Tiêu cực', 'Trung tính', 'Tích cực'][i]}: ${t[k]}`)} style="width:${(t[k] / t.total) * 100}%;background:var(${['--bad', '--neutral', '--good'][i]})"></i>` : '').join('')}</div><b style="text-align:right">${t.total}<span class="muted"> · ${t.negative}↓</span></b></div>`).join('')}</div>
      <div class="legend"><span><i style="background:var(--bad)"></i>Tiêu cực</span><span><i style="background:var(--neutral)"></i>Trung tính</span><span><i style="background:var(--good)"></i>Tích cực</span></div></div>
      <div class="card"><h3>Từ khóa xuất hiện nhiều (viền đỏ: có nhiều review tiêu cực chứa từ này)</h3><div class="keywords">${d.keywords.map((w) => `<span class="kw ${w.negative > w.count / 2 ? 'neg' : ''}">${esc(w.term)}<b>${w.count}</b></span>`).join('') || '<span class="muted">Chưa đủ dữ liệu</span>'}</div></div>`
    );
  },

  async sov() {
    const d = await api('sov');
    const colOf = (id) => entColor(d.entities, id);
    const name = (id) => d.search.web.shares.find((s) => s.id === id)?.name || id;
    const bars = (sh) => `<div class="bars">${sh.shares.map((s) => `<div class="bar" style="grid-template-columns:150px 1fr 50px"><span>${esc(s.name)}</span><div class="tr"><i style="width:${s.share * 100}%;background:var(${colOf(s.id)})"></i></div><b style="text-align:right">${pct(s.share)}</b></div>`).join('')}</div>`;
    return (
      head('Share of Voice', `So với đối thủ · Google Search/News cập nhật ${fmtTime(d.search.at)}`) + banner() +
      `<div class="grid g2" style="margin-bottom:14px"><div class="card"><h3>Google Search (top 10, trọng số theo vị trí)</h3>${bars(d.search.web)}</div><div class="card"><h3>Google News</h3>${bars(d.search.news)}</div></div>
      <div class="card"><h3>So sánh review với đối thủ</h3>${compTable(d.table, d.prev, { entities: d.entities, extra: true, lastCompetitorSync: d.lastCompetitorSync })}</div>
      <div class="card"><h3>Kết quả tìm kiếm đã thu thập</h3><div class="scroll"><table><tr><th>Từ khóa</th><th>Nguồn</th><th class="num">Vị trí</th><th>Thuộc về</th><th>Tiêu đề</th></tr>${d.items.map((i) => `<tr><td>${esc(i.keyword)}</td><td>${i.source === 'google_news' ? 'News' : 'Search'}</td><td class="num">${i.position}</td><td>${esc(i.entity === 'other' ? 'Nguồn khác' : name(i.entity))}</td><td>${/\.example\b|\/mau\//.test(i.url) ? esc(i.title) : `<a href="${esc(i.url)}" target="_blank" rel="noopener">${esc(i.title)}</a>`}</td></tr>`).join('') || '<tr><td colspan="5" class="muted">Chưa có dữ liệu</td></tr>'}</table></div></div>`
    );
  },

  async social() {
    return (
      head('Social Listening', 'Theo dõi mention trên Facebook, TikTok, YouTube') +
      `<div class="card"><div class="empty"><b style="color:var(--text-primary)">Chưa kết nối nguồn dữ liệu mạng xã hội</b><p>Module này nằm trong giai đoạn sau, nên hiện không có số liệu (không dùng dữ liệu giả để tránh nhầm với dữ liệu thật).</p><p>Khi triển khai: thêm một adapter trong <code>lib/providers/</code> (ví dụ Apify hoặc YouTube Data API) trả về mention theo cùng cấu trúc với kết quả Google Search; phần phân tích cảm xúc, cảnh báo và báo cáo dùng lại được ngay.</p></div></div>`
    );
  },

  async crisis() {
    const d = await api('crisis');
    const [lab, tone] = LEVEL[d.level];
    return (
      head('Crisis Monitoring', 'Phát hiện sớm rủi ro danh tiếng từ review') + banner() +
      `<div class="banner ${tone === 'bad' || tone === 'warn' ? 'crit' : ''}">Trạng thái hiện tại (7 ngày): <b>${lab}</b></div>
      <div class="card"><h3>Review tiêu cực mỗi ngày (30 ngày)</h3>${simpleBars(d.daily.map((x) => ({ k: x.date, v: x.negative })))}</div>
      <div class="card"><h3>Nghi review tấn công (nhiều tài khoản cùng nội dung)</h3>${d.duplicates.length ? d.duplicates.map((g) => `<div style="margin-bottom:10px"><b>“${esc(g[0].text.slice(0, 140))}”</b><div class="muted">${g.map((r) => `${esc(r.author)} (${fmtDate(r.date)})`).join(' · ')}</div></div>`).join('') : '<div class="empty">Không phát hiện</div>'}</div>
      <div class="card"><h3>Review nghiêm trọng (mức 2-3, 30 ngày)</h3>${d.severe.map((r) => reviewHtml(r)).join('') || '<div class="empty">Không có</div>'}</div>`
    );
  },

  async alerts() {
    const d = await api('alerts');
    const ic = { critical: ['⛔', 'var(--bad)'], warning: ['⚠', 'var(--warn)'], info: ['ℹ', 'var(--series-1)'] };
    return (
      head('Cảnh báo real-time', `${d.unread} chưa đọc · tự cập nhật khi đồng bộ`, `<button class="btn" data-act="readall">Đánh dấu đã đọc tất cả</button>`) + banner() +
      `<div class="card">${d.alerts.map((a) => `<div class="alert ${a.read ? '' : 'unread'}"><span style="color:${ic[a.level][1]};font-size:18px">${ic[a.level][0]}</span><div><div class="t">${esc(a.title)} <span class="chip">${a.level}</span></div><div class="muted">${esc(a.detail)}</div><div class="meta muted">${fmtTime(a.createdAt)}</div></div>${a.read ? '' : `<button class="btn" data-act="readone" data-v="${a.id}">Đã đọc</button>`}</div>`).join('') || '<div class="empty">Chưa có cảnh báo</div>'}</div>`
    );
  },

  async reviews() {
    const q = new URLSearchParams({ limit: 20, offset: 0, sort: S.sort });
    if (S.stars !== 'all') q.set('stars', S.stars);
    if (S.branch) q.set('branch', S.branch);
    const d = await api('reviews?' + q);
    S.rows = d.items;
    S.total = d.total;
    const sc = Object.fromEntries(d.starCounts.map((x) => [x.star, x.n]));
    const n = d.starCounts.reduce((s, x) => s + x.n, 0);
    const maxN = Math.max(1, ...d.starCounts.map((x) => x.n));
    const label = S.stars === 'all' ? 'tất cả' : `${S.stars} sao`;
    const avgAll = n ? d.starCounts.reduce((s, x) => s + x.star * x.n, 0) / n : null;
    const big = d.google ? d.google.rating : avgAll;
    const sorts = [['newest', 'Mới nhất'], ['low', 'Thấp nhất'], ['high', 'Cao nhất']];
    return (
      head('Google Review', S.stars === 'all' ? 'Hiển thị đánh giá mọi mức sao từ Google Maps' : `Chỉ hiển thị đánh giá ${S.stars} sao từ Google Maps`) + banner() +
      `<div class="card"><div class="rating-summary">
        <div class="rs-score"><div class="big">${fmtRating(big)}</div><div>${stars(Math.round(big || 0))}</div><div class="cnt">${d.google ? `${fmtInt(d.google.total)} đánh giá trên Google` : `${fmtInt(n)} đánh giá`}</div></div>
        <div><div class="rbars">${[5, 4, 3, 2, 1].map((s) => `<button class="rbar ${S.stars === String(s) ? 'on' : ''}" data-act="star" data-v="${s}" title="${S.stars === String(s) ? 'Bỏ lọc' : `Chỉ xem review ${s} sao`}"><span>${s}</span><span class="track"><span class="fill" style="width:${(sc[s] / maxN) * 100}%"></span></span><span class="num">${fmtInt(sc[s])}</span></button>`).join('')}</div>
        <div class="cnt" style="margin-top:6px">Phân bố trên ${fmtInt(n)} review đã thu thập${S.branch ? ` · ${esc(S.branch)}` : ''}. Bấm một thanh để lọc theo số sao, bấm lại để bỏ lọc.</div></div>
      </div></div>
      <div class="card"><h3>Theo chi nhánh — review ${label}</h3>${d.branches.map((b) => `<div class="acc ${S.branch === b.branch ? 'on' : ''}"><button data-act="branch" data-v="${esc(b.branch)}"><b>${esc(b.branch)}</b><span class="chip neg" style="margin-left:auto">${b.total} review</span></button></div>`).join('') || '<div class="empty">Không có</div>'}${S.branch ? '<button class="btn" data-act="branch" data-v="">Bỏ lọc chi nhánh</button>' : ''}</div>
      <div class="card"><div class="head" style="margin-bottom:4px"><h3 style="margin:0">Đánh giá ${label} (${fmtInt(d.total)})</h3><div class="tabs">${sorts.map(([k, t]) => `<button class="btn ${S.sort === k ? 'on' : ''}" data-act="sort" data-v="${k}">${t}</button>`).join('')}</div></div>
      <div id="revlist">${d.items.map((r) => reviewHtml(r)).join('') || '<div class="empty">Không có review</div>'}</div>${d.total > d.items.length ? `<div style="text-align:center;margin-top:10px"><button class="btn" data-act="more">Xem thêm (${d.total - d.items.length})</button></div>` : ''}</div>`
    );
  },

  async reputation() {
    const d = await api('reputation');
    const snaps = d.snapshots;
    const w = d.weekly.filter((x) => x.avg != null);
    return (
      head('Reputation Tracking', 'Theo dõi biến động danh tiếng theo thời gian') + banner() +
      `<div class="grid g2" style="margin-bottom:14px"><div class="card"><h3>Brand Health Score theo ngày</h3>${snaps.length >= 2 ? lineChart(snaps.map((s) => fmtDate(s.date)), [{ name: 'Brand Health', color: '--series-1', vals: snaps.map((s) => s.health) }], { min: 0, max: 100, dec: 0 }) : '<div class="empty">Cần ít nhất 2 ngày dữ liệu. Hệ thống ghi một điểm mỗi ngày khi đồng bộ.</div>'}</div>
      <div class="card"><h3>Sao trung bình theo tuần</h3>${lineChart(w.map((x) => new Date(x.week).toLocaleDateString('vi-VN', { day: '2-digit', month: '2-digit' })), [{ name: 'Sao TB', color: '--series-1', vals: w.map((x) => x.avg) }], { min: Math.min(3, Math.floor(Math.min(5, ...w.map((x) => x.avg)))), max: 5 })}</div></div>
      <div class="card"><h3>So sánh đối thủ</h3>${compTable(d.table, d.prev, { lastCompetitorSync: d.lastCompetitorSync })}</div>
      <div class="card"><h3>Nhật ký đồng bộ</h3><table><tr><th>Thời gian</th><th>Chế độ</th><th class="num">Review mới</th><th class="num">Đã phân tích</th><th class="num">Cảnh báo mới</th><th>Ghi chú</th></tr>${d.syncLog.map((l) => { const n = (l.notes || []).join('; '); return `<tr class="${/Lỗi/.test(n) ? 'err' : ''}"><td>${fmtTime(l.at)}</td><td>${l.mode}</td><td class="num">${l.added}</td><td class="num">${l.analyzed}</td><td class="num">${l.alerts}</td><td class="muted notes" title="${esc(n)}">${esc(n)}</td></tr>`; }).join('')}</table></div>`
    );
  },

  async reports() {
    const d = await api('reports');
    return (
      head('Báo cáo tự động', 'Tạo báo cáo HTML (in ra PDF bằng trình duyệt). Hệ thống tự tạo báo cáo tuần vào thứ Hai.', `<div class="tabs"><button class="btn primary" data-act="report" data-days="7">Tạo báo cáo 7 ngày</button><button class="btn" data-act="report" data-days="30">Tạo báo cáo 30 ngày</button></div>`) + banner() +
      `<div class="card"><table><tr><th>Báo cáo</th><th>Kỳ</th><th>Tạo lúc</th><th></th></tr>${d.reports.map((r) => `<tr><td>${esc(r.file)}</td><td>${r.days} ngày</td><td>${fmtTime(r.createdAt)}</td><td><a href="/reports/${encodeURIComponent(r.file)}" target="_blank">Mở</a></td></tr>`).join('') || '<tr><td colspan="4" class="muted">Chưa có báo cáo</td></tr>'}</table></div>`
    );
  },
};

/* ---------- shell ---------- */
function renderSide() {
  const b = cur();
  const bs = S.cfg.brands;
  const [lab] = LEVEL[b.level];
  const hs = b.health;
  const R = 22, C = 2 * Math.PI * R;
  S.sideHtml = `<div class="brandbox"><div class="logo"><i></i><i></i><i></i><i></i></div><div><b>Brand Command</b><span class="muted" style="font-size:12px">CheckBrand</span></div></div>
  <select class="brandsel" id="brandsel">${bs.map((x) => `<option value="${x.id}" ${x.id === S.brand ? 'selected' : ''}>${esc(x.name)}</option>`).join('')}</select>
  ${NAV.map(([g, items]) => `<div class="grp">${g}</div>${items.map(([id, ic, t]) => `<button class="nav ${S.route === id ? 'on' : ''}" data-act="nav" data-v="${id}"><span class="ic">${ic}</span>${t}${id === 'alerts' && b.unread ? `<span class="badge">${b.unread}</span>` : ''}</button>`).join('')}`).join('')}
  <div class="healthcard"><div class="t">Brand Health Score</div><div class="row" style="margin-top:6px"><svg width="54" height="54" viewBox="0 0 54 54"><circle cx="27" cy="27" r="${R}" fill="none" stroke="var(--line)" stroke-width="6"/><circle cx="27" cy="27" r="${R}" fill="none" stroke="var(${hs >= 80 ? '--good' : hs >= 60 ? '--warn' : '--bad'})" stroke-width="6" stroke-linecap="round" stroke-dasharray="${((hs || 0) / 100) * C} ${C}" transform="rotate(-90 27 27)"/><text x="27" y="31" text-anchor="middle" style="font-size:13px;font-weight:650;fill:var(--text-primary)">${hs ?? '-'}</text></svg><div><b>${hs ?? '-'}</b><span class="muted">/100</span><div class="muted" style="font-size:11px">Khủng hoảng: ${lab}</div></div></div></div>
  <div class="sidefoot"><button class="btn" data-act="sync" id="syncbtn">${b.syncing ? 'Đang cập nhật…' : '↻ Cập nhật ngay'}</button><button class="btn" data-act="theme">${document.documentElement.dataset.theme === 'dark' ? '☀ Giao diện sáng' : '☾ Giao diện tối'}</button>
  <div class="live"><span class="dot ${S.live ? '' : 'off'}"></span>${S.live ? 'LIVE — đang kết nối' : 'Mất kết nối'} · ${fmtTime(b.lastSync)}</div></div>`;
  $('#side').innerHTML = S.sideHtml;
}

async function loadCfg() {
  S.cfg = await fetch('/api/config').then((r) => r.json());
  S.topicLabels = S.cfg.topics;
  if (!S.cfg.brands.some((b) => b.id === S.brand)) S.brand = S.cfg.brands[0]?.id;
}

async function render() {
  const sy = window.scrollY;
  renderSide();
  try {
    $('#main').innerHTML = await pages[S.route]();
    fitMore($('#main'));
  } catch (e) {
    $('#main').innerHTML = `<div class="card"><div class="empty">Lỗi tải dữ liệu: ${esc(e.message)}</div></div>`;
  }
  window.scrollTo(0, sy);
}

// Tải thêm 20 review vào danh sách đang xem (nút "Xem thêm")
async function loadMore(btn) {
  const q = new URLSearchParams({ limit: 20, offset: S.rows.length, sort: S.sort });
  if (S.stars !== 'all') q.set('stars', S.stars);
  if (S.branch) q.set('branch', S.branch);
  const d = await api('reviews?' + q);
  S.rows.push(...d.items);
  $('#revlist').insertAdjacentHTML('beforeend', d.items.map((r) => reviewHtml(r)).join(''));
  fitMore($('#revlist'));
  if (S.rows.length >= S.total || !d.items.length) btn.remove();
  else btn.textContent = `Xem thêm (${S.total - S.rows.length})`;
}

// Dùng cho notify.js: mở trang Google Review đúng brand + mức sao, tải thêm trang tới khi thấy review theo id
window.CB = {
  async showReview({ brandId, rating, id }) {
    if (brandId && brandId !== S.brand && S.cfg.brands.some((b) => b.id === brandId)) {
      S.brand = brandId;
      localStorage.setItem('cb-brand', S.brand);
    }
    Object.assign(S, { route: 'reviews', stars: String(rating), branch: '', sort: 'newest' });
    if (location.hash !== '#reviews') history.replaceState(null, '', '#reviews');
    await render();
    const find = () => [...document.querySelectorAll('#revlist .rev')].find((el) => el.dataset.id === id);
    for (let i = 0; i < 20 && !find(); i++) {
      const more = document.querySelector('[data-act="more"]');
      if (!more) break;
      await loadMore(more);
    }
    return find() || null;
  },
};

function toast(msg) {
  const t = document.createElement('div');
  t.className = 'toast';
  t.innerHTML = msg;
  $('#toasts').append(t);
  setTimeout(() => t.remove(), 9000);
}

document.addEventListener('click', async (e) => {
  const el = e.target.closest('[data-act]');
  if (!el) return;
  const act = el.dataset.act, v = el.dataset.v;
  if (act === 'expand') {
    const open = el.previousElementSibling.classList.toggle('open');
    el.textContent = open ? 'Ẩn bớt' : 'Thêm';
    return;
  }
  if (act === 'nav') { S.route = v; location.hash = v; S.branch = ''; return render(); }
  if (act === 'star') { S.stars = v === S.stars ? 'all' : v; return render(); }
  if (act === 'sort') { S.sort = v; return render(); }
  if (act === 'branch') { S.branch = v === S.branch ? '' : v; return render(); }
  if (act === 'range') { S.days = +v; return render(); }
  if (act === 'theme') {
    const t = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
    document.documentElement.dataset.theme = t;
    localStorage.setItem('cb-theme', t);
    return render();
  }
  if (act === 'more') return loadMore(el);
  if (act === 'sync') {
    el.disabled = true;
    el.textContent = 'Đang cập nhật…';
    // Chỉ lấy review mới; Google Search/News vẫn tự cập nhật theo SEARCH_INTERVAL_HOURS để tiết kiệm credit
    await post('sync');
    await loadCfg();
    return render();
  }
  if (act === 'readall') { await post('read'); await loadCfg(); return render(); }
  if (act === 'readone') { await post('read', { id: v }); await loadCfg(); return render(); }
  if (act === 'report') {
    el.disabled = true;
    const r = await post('reports', { days: +el.dataset.days });
    window.open('/reports/' + encodeURIComponent(r.file), '_blank');
    return render();
  }
});

document.addEventListener('change', async (e) => {
  if (e.target.id === 'brandsel') {
    S.brand = e.target.value;
    localStorage.setItem('cb-brand', S.brand);
    S.branch = '';
    render();
  }
});

// Tooltip dùng chung cho mọi biểu đồ
const tip = $('#tip');
document.addEventListener('mousemove', (e) => {
  const t = e.target.closest('[data-tip]');
  if (!t) return (tip.style.display = 'none');
  tip.innerHTML = t.dataset.tip;
  tip.style.display = 'block';
  const w = tip.offsetWidth;
  tip.style.left = Math.min(window.innerWidth - w - 8, e.clientX + 14) + 'px';
  tip.style.top = e.clientY + 14 + 'px';
});

window.addEventListener('hashchange', () => {
  const r = location.hash.slice(1);
  if (pages[r] && r !== S.route) { S.route = r; render(); }
});

function connect() {
  const es = new EventSource('/api/stream');
  es.onopen = () => { S.live = true; if (S.cfg) renderSide(); };
  es.onerror = () => { S.live = false; if (S.cfg) renderSide(); };
  es.addEventListener('sync', async (ev) => {
    const d = JSON.parse(ev.data);
    await loadCfg();
    if (d.brand === S.brand) render();
    else renderSide();
  });
  es.addEventListener('alert', (ev) => {
    const d = JSON.parse(ev.data);
    // Review xấu từng cái đã có chuông + toast của notify.js; ở đây chỉ báo cảnh báo tổng hợp (tăng đột biến, tụt điểm, nghi tấn công)
    if (d.key?.startsWith('sev:')) return;
    const b = S.cfg?.brands.find((x) => x.id === d.brand);
    toast(`<b>${esc(b?.name || d.brand)}</b><br>${esc(d.title)}`);
  });
}

(async function init() {
  document.documentElement.dataset.theme = localStorage.getItem('cb-theme') || 'dark';
  if (!pages[S.route]) S.route = 'overview';
  await loadCfg();
  await render();
  connect();
})();
